// default novels with chapters
window.NOVELS = [
  {
    "id":"fantasy1",
    "title":"The Dragon's Prophecy",
    "genre":"Fantasy",
    "pages":360,
    "cover":"https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=900&q=80",
    "desc":"In a realm where dragons are a memory, a young scribe discovers a prophecy inked in blood.",
    "chapters":[
      {"cid":"c1","title":"Chapter 1 — Ashes","content":"He remembered the smell of ash..."},
      {"cid":"c2","title":"Chapter 2 — The Map","content":"The map was folded into thirds..."}
    ]
  },
  {
    "id":"scifi1",
    "title":"Whispers of Tomorrow",
    "genre":"Sci-Fi",
    "pages":200,
    "cover":"https://images.unsplash.com/photo-1544931347-176ae0573d7d?auto=format&fit=crop&w=900&q=80",
    "desc":"When machine dreams leak into reality, a coder must follow them to the edge of a new world.",
    "chapters":[
      {"cid":"c1","title":"Chapter 1 — Echo","content":"The server hummed a lullaby..."},
      {"cid":"c2","title":"Chapter 2 — Signal","content":"A signal arrived at dawn..."}
    ]
  }
];
